from pathlib import Path
import glob, pandas as pd, numpy as np
from common import load_config, set_seed, ensure_dirs

def main():
    cfg=load_config(); set_seed(cfg['seed']); ensure_dirs()
    files=glob.glob(cfg['dataset']['input_glob'])
    if not files:
        raise SystemExit('No CSV files found in data/raw/. Add CICIoT2023 CSV files first.')
    frames=[pd.read_csv(f, low_memory=False) for f in files]
    df=pd.concat(frames, ignore_index=True)
    label=None
    for c in cfg['dataset']['label_candidates']:
        if c in df.columns: label=c; break
    if label is None: raise SystemExit('Could not identify label column. Update label_candidates in configs/pilot.yaml.')
    y=df[label].astype(str)
    X=df.drop(columns=[label]).select_dtypes(include=[np.number]).replace([np.inf,-np.inf],np.nan)
    X=X.fillna(X.median(numeric_only=True)).fillna(0)
    out=X.copy(); out['__label__']=y.values
    out.to_parquet('data/processed/ciciot2023_numeric.parquet', index=False)
    print(f'Saved {len(out):,} rows, {X.shape[1]} numeric features; label={label}')
if __name__=='__main__': main()
