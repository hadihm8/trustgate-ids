from pathlib import Path
import random, yaml
import numpy as np

def load_config(path="configs/pilot.yaml"):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def set_seed(seed):
    random.seed(seed); np.random.seed(seed)

def ensure_dirs():
    for p in ["data/processed", "results", "figures", "statistics"]:
        Path(p).mkdir(parents=True, exist_ok=True)
