import time, json, psutil, numpy as np, pandas as pd
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score
from sklearn.model_selection import train_test_split
from common import load_config, set_seed, ensure_dirs

def poison_labels(y, rate, rng):
    y=y.copy(); n=int(len(y)*rate)
    if n==0: return y
    idx=rng.choice(len(y), n, replace=False); classes=np.unique(y)
    for i in idx:
        choices=classes[classes!=y[i]]
        if len(choices): y[i]=rng.choice(choices)
    return y

def metrics(y,p):
    return dict(accuracy=accuracy_score(y,p), macro_f1=f1_score(y,p,average='macro',zero_division=0),
                precision_macro=precision_score(y,p,average='macro',zero_division=0),
                recall_macro=recall_score(y,p,average='macro',zero_division=0))

def fit_model(X,y,cfg):
    m=RandomForestClassifier(n_estimators=cfg['model']['n_estimators'], class_weight=cfg['model']['class_weight'], n_jobs=-1, random_state=cfg['seed'])
    t=time.perf_counter(); m.fit(X,y); return m,time.perf_counter()-t

def main():
    cfg=load_config(); set_seed(cfg['seed']); ensure_dirs(); rng=np.random.default_rng(cfg['seed'])
    path=Path('data/processed/ciciot2023_numeric.parquet')
    if not path.exists(): raise SystemExit('Run: python src/preprocess.py')
    df=pd.read_parquet(path); X=df.drop(columns='__label__'); y=df['__label__'].to_numpy()
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=cfg['experiment']['test_size'],random_state=cfg['seed'],stratify=y)
    # chronological adaptation proxy for pilot: split training tail into adaptation + clean validation
    Xa,Xv,ya,yv=train_test_split(Xtr,ytr,test_size=cfg['experiment']['validation_fraction'],random_state=cfg['seed'],stratify=ytr)
    rows=[]
    for rate in cfg['experiment']['poison_rates']:
        yp=poison_labels(ya,rate,rng)
        naive,tfit=fit_model(Xa,yp,cfg); pv=naive.predict(Xv); trust=f1_score(yv,pv,average='macro',zero_division=0)
        accepted=trust>=cfg['experiment']['trust_threshold']
        if accepted: deployed=naive
        else: deployed,_=fit_model(Xa,ya,cfg)
        t=time.perf_counter(); pred=deployed.predict(Xte); infer=(time.perf_counter()-t)/len(Xte)*1000
        r={'poison_rate':rate,'trust_score':trust,'update_accepted':accepted,'fit_seconds':tfit,'inference_ms_per_sample':infer,'rss_mb':psutil.Process().memory_info().rss/1024**2}
        r.update(metrics(yte,pred)); rows.append(r)
    out=pd.DataFrame(rows); out.to_csv('results/pilot_results.csv',index=False); print(out.to_string(index=False))
    with open('results/pilot_manifest.json','w') as f: json.dump({'seed':cfg['seed'],'rows':len(df),'features':X.shape[1]},f,indent=2)
if __name__=='__main__': main()
