#!/usr/bin/env bash
set -euo pipefail
python src/preprocess.py
python src/pilot.py
