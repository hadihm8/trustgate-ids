# TrustGate-IDS

Reproducible research prototype for **trust-gated continual intrusion detection under adversarial concept drift and adaptation poisoning**.

## Research purpose
The project evaluates whether an adaptive IDS can protect its own model-update process when adaptation data are manipulated. The pilot deliberately starts with a simple, auditable trust gate before adding streaming drift detectors, stronger continual-learning baselines, adversarial drift, rollback, and cross-dataset validation.

## Pilot dataset
The first pilot uses **CICIoT2023**. Dataset files are not redistributed here. Obtain the dataset from its official source and place CSV files in `data/raw/`.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python src/preprocess.py
python src/pilot.py
```

Outputs are written to `results/`.

## Pilot design
Poisoning intensities: 0%, 1%, 5%, 10%, 20%. The pilot trains an adaptation model, evaluates it on a held-out clean validation set, and permits deployment only when the validation Macro-F1 satisfies the configured trust threshold. This is a **pilot mechanism**, not the final Trust Gate claimed by the paper.

## Planned full study
1. Temporal/stream construction without random leakage.
2. Natural abrupt, gradual, and recurring drift.
3. Adversarial drift and adaptation poisoning.
4. Static, naive-continual, drift-aware, and TrustGate baselines.
5. Post-update validation and rollback.
6. Recovery time, forgetting, backward/forward transfer, zero-day recall, poisoning success, latency, and memory.
7. Ablation and sensitivity analysis.
8. External validation on Edge-IIoTset and ToN-IoT.

## Reproducibility
Random seeds and experiment settings are stored in `configs/pilot.yaml`. Raw datasets and generated results should not be committed if they are large.

## Ethics
This repository is intended for defensive cybersecurity research in controlled datasets and test environments. It does not contain tooling for attacking external systems.
